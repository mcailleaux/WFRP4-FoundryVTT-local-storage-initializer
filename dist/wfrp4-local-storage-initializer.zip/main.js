Hooks.once('init', () => {
    localStorage.setItem('wfrp4e.weaponLength', true);
    localStorage.setItem('pings.image', '"modules/wfrp4e-core/icons/mutations/mutation.png"');
    localStorage.setItem('pings.scale', 4);
    localStorage.setItem('one-journal.openButtonInSidebarDirectory', true);
});
